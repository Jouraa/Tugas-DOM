const gambarBF = "bloxfruit.png";
const gambarKL = "kinglegacy.png";
let berubah = false

function UbahKonten() {
    let judul = document.getElementById("judul");
    let subjudul = document.getElementById("subjudul");
    let gambar = document.getElementById("gambar");
    let tombol = document.querySelector("bn");

    if (berubah) {
        gambar.src = gambarBF;
        judul.textContent = "Blox Fruit";
        subjudul.textContent = "Game Bagus"
    }else {
        gambar.src = gambarKL;
        judul.textContent = "King Legacy"
        subjudul.textContent = "Game Jelek";
    }

    berubah = !berubah;


}